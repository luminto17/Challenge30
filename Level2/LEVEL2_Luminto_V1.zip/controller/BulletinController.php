<?php

require_once('model/Database.php');
require_once('model/Bulletin.php');
require_once('model/Pagination.php');

class BulletinController
{ 
  private $bulletinObj = NULL;

  public function __construct()
  {
    $this->bulletinObj = new Bulletin();
  }

  public function post()
  {
    $title = isset($_POST['title']) ? $_POST['title'] : NULL;
    $body  = isset($_POST['body']) ? $_POST['body'] : NULL;

    $errors = $this->bulletinObj->validate($title, $body);

    if (empty($errors)) {
      $this->bulletinObj->insert(array(
        'title'    => $title, 
        'body'     => $body,
        'is_alive' => 1
      ));

      header('Location:index.php');	
      exit;
    }

    include('view/Error.php');
  }

  public function preview()
  {
    $id   = isset($_POST['id']) ? $_POST['id'] : NULL;
    $page = isset($_POST['page']) ? $_POST['page'] : NULL;

    $bulletin = $this->bulletinObj->fetch(null, "id = {$id}");

    include('view/Delete.php');
  }

  public function showBulletins()
  {
    $order         = 'id DESC';
    $condition     = 'is_alive = 1';
    $errors        = array();
    $bulletins     = $this->bulletinObj->fetch(null, $condition, $order);
    $paginationObj = new Pagination(count($bulletins));

    if (!empty($_GET["page"])) {
      $paginationObj->setCurrentPage($_GET["page"]);
    } else {
      $paginationObj->setCurrentPage(1);
    }

    $bulletins   = $this->bulletinObj->fetch(null, $condition, $order, $paginationObj->getItemPerPage(), $paginationObj->getOffset());
    $pageNumbers = $paginationObj->getPageNumbers();

    $paginationObj->setUri("http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]", array("page" => $paginationObj->getCurrentPage()));

    include('view/BulletinBoard.php');
  }

  public function delete()
  {
    if ($_POST['submitted'] === "Yes") {
      $id = isset($_POST['id']) ? $_POST['id'] : NULL;

      $this->bulletinObj->delete("id=" . $id);
    }

    header('Location:index.php?page=' . $_POST['page']);
    exit;
  }
}