<?php

function get_value($value) {
  $params = array_merge($_POST, $_GET);

  return isset($params[$value]) ? $params[$value] : NULL;
}