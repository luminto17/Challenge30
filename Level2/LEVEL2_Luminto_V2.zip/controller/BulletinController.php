<?php

require_once('model/Database.php');
require_once('model/Bulletin.php');
require_once('model/Pagination.php');

class BulletinController
{
  public function getValue($value)
  {
    $params = array_merge($_POST, $_GET);
    
    return isset($params["{$value}"]) ? $params["{$value}"] : NULL;
  }

  public function post()
  {
    $bulletinObj = new Bulletin();

    $title = $this->getValue('title');
    $body  = $this->getValue('body');

    $errors = $bulletinObj->validate($title, $body);

    if (empty($errors)) {
      $bulletinObj->insert(array(
        'title'    => $title, 
        'body'     => $body,
        'is_alive' => 1
      ));

      header('Location:index.php');	
      exit;
    }

    include('view/Error.php');
  }

  public function showBulletins()
  {
    $bulletinObj   = new Bulletin();
    $paginationObj = new Pagination($bulletinObj->count());

    $errors = array();

    $paginationObj->setCurrentPage($this->getValue('page'));

    $bulletins   = $bulletinObj->fetch(null, "is_alive = 1", "id DESC", $paginationObj->getItemPerPage(), $paginationObj->getOffset());
    $pageNumbers = $paginationObj->getPageNumbers();

    $paginationObj->setUri("http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");

    include('view/BulletinBoard.php');
  }

  public function delete()
  {
    $bulletinObj   = new Bulletin();
    $paginationObj = new Pagination($bulletinObj->count());

    $id        = $this->getValue('id');
    $page      = $this->getValue('page');
    $submitted = isset ($_POST['submitted']) ? $_POST['submitted'] : NULL;

    $bulletin = $bulletinObj->fetch(null, "id = {$id} AND is_alive = 1");

    if (!$paginationObj->verifyPage($page) || empty($bulletin)) {
      header('HTTP/1.1 400 Bad Request');
      exit;
    }

    $paginationObj->setCurrentPage($page);

    if (!empty($submitted)) {
      if ($submitted === "Yes") {
        $bulletinObj->delete("id=" . $id);
      }

      header('Location:index.php?page=' . $paginationObj->getCurrentPage());
      exit;
    } else {
      $title = $bulletin[0]['title'];
      $body  = $bulletin[0]['body'];
      $time  = $bulletin[0]['created_at'];

      include('view/Delete.php');
    }   
  }
}