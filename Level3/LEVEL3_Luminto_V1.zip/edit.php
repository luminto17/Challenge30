<?php

require_once('controller/BulletinController.php');

$bulletinController = new BulletinController();

$bulletinController->edit();